# Kit REA Somos Jándula

Este paquete ayuda a trasladar a otros centros una experiencia de aprendizaje basada en necesidades reales, desarrollo de software, revisión funcional y conservación de evidencias.

## Contenido

- `guia-aplicacion-somos-jandula`: guía didáctica y organizativa.
- `rubrica-competencia-digital-somos-jandula`: rúbrica de observación adaptada a las cinco áreas de DigComp 2.2.
- `plantilla-tarea-revision-somos-jandula`: plantilla para definir, revisar y cerrar una tarea.
- `ejemplo-tarea-revision-dom-248`: ejemplo cumplimentado y anonimizado.

Cada material se ofrece en PDF y DOCX editable. La rúbrica es un recurso elaborado después del curso 2025-2026 y no se utilizó para calcular sus calificaciones.

## Enlaces

- Experiencia: https://somos.iesjandula.es/experiencia
- Seguimiento público: https://sharing.clickup.com/2503283/b/h/4-90121296946-2/79af6313b7ad7dc
- GitHub: https://github.com/IESJandula
- Documentación técnica: https://github.com/IESJandula/Reaktor_Documentacion

## Licencia

CC BY-SA 4.0. Consulte `LICENSE.txt` y https://creativecommons.org/licenses/by-sa/4.0/deed.es.
